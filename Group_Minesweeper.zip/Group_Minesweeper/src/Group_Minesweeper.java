import java.io.*;
import java.util.*;

public class Group_Minesweeper {

	public static void main(String[] args) {
		int count = 1;
		int rows, cols;
		String[] field;
		int[][] hint;
		Scanner fin = new Scanner(System.in);

		checkEmptyFile(fin);

		rows = fin.nextInt();
		cols = fin.nextInt();

		checkEmptyField(rows, cols);

		while (rows > 0 && cols > 0 && fin.hasNext()) {
			fin.nextLine();

			field = createField(rows, fin);
			hint = createHint(field, rows, cols);
			hint = addNums(hint, rows, cols);

			System.out.println("Field #" + count);
			printHints(hint, rows, cols);

			count++;

			checkEmptyFile(fin);

			rows = fin.nextInt();
			cols = fin.nextInt();
		}

	}

	/*
	 * Simple check to see if the file is empty. If the file is empty the
	 * program exits and displays a message
	 */
	private static void checkEmptyFile(Scanner fin) {
		if (!fin.hasNext()) {
			System.out.println("File is empty.");
			System.exit(-1);
		}
	}

	/*
	 * Simple check to see if the file contains an empty field. If the rows or
	 * cols are 0 the program exits and displays a message
	 */
	private static void checkEmptyField(int rows, int cols) {
		if (rows == 0 || cols == 0) {
			System.out.println("Mine field was empty.");
			System.exit(-1);
		}
	}

	/*
	 * Creates an array of Strings from the file based on each line of the file
	 * passed in. Returns the String[]
	 */
	private static String[] createField(int rows, Scanner fin) {
		String[] array = new String[rows];

		for (int r = 0; r < rows; r++) {
			array[r] = fin.nextLine();
		}

		return array;
	}

	/*
	 * Creates a template for the field using 0 as none bomb locations and -1 as
	 * bomb locations. It looks at each line of the field array then each char
	 * of the String to see if it is a bomb. Returns the int [][]
	 */
	private static int[][] createHint(String[] field, int rows, int cols) {
		int r, c;
		int[][] hint = new int[rows][cols];

		for (r = 0; r < rows; r++) {
			for (c = 0; c < cols; c++) {
				if (field[r].charAt(c) == '*')
					hint[r][c] = -1;
				else
					hint[r][c] = 0;
			}
		}

		return hint;
	}

	/*
	 * Walks through the hint array and increments the non-bomb locations by one
	 * if it fits the conditional. Returns the hint array after all the hint
	 * numbers have been added
	 */
	private static int[][] addNums(int[][] hint, int rows, int cols) {
		int r, c;

		for (r = 0; r < rows; r++) {
			for (c = 0; c < cols; c++) {
				if (hint[r][c] == -1) {
					if (r - 1 >= 0)
						if (hint[r - 1][c] != -1)
							hint[r - 1][c] += 1;
					if (r + 1 < rows)
						if (hint[r + 1][c] != -1)
							hint[r + 1][c] += 1;
					if (c - 1 >= 0)
						if (hint[r][c - 1] != -1)
							hint[r][c - 1] += 1;
					if (c + 1 < cols)
						if (hint[r][c + 1] != -1)
							hint[r][c + 1] += 1;
					if (r - 1 >= 0 && c - 1 >= 0)
						if (hint[r - 1][c - 1] != -1)
							hint[r - 1][c - 1] += 1;
					if (r - 1 >= 0 && c + 1 < cols)
						if (hint[r - 1][c + 1] != -1)
							hint[r - 1][c + 1] += 1;
					if (r + 1 < rows && c + 1 < cols)
						if (hint[r + 1][c + 1] != -1)
							hint[r + 1][c + 1] += 1;
					if (r + 1 < rows && c - 1 >= 0)
						if (hint[r + 1][c - 1] != -1)
							hint[r + 1][c - 1] += 1;
				}
			}
		}

		return hint;
	}

	/*
	 * Walks through each element of the int[][] hint. Checks to see if the
	 * number is a bomb, represented with a -1. If it comes across a -1 it
	 * prints out *, otherwise it will print the number at the location
	 */
	private static void printHints(int[][] hint, int rows, int cols) {
		int r, c;

		for (r = 0; r < rows; r++) {
			for (c = 0; c < cols; c++) {
				if (hint[r][c] == -1)
					System.out.print("*");
				else
					System.out.print(hint[r][c]);
			}
			System.out.println();
		}
	}

}
